using System;
using System.Drawing;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using System.Text;

namespace SKP.ASP.Controls
{
    public class CurrencyTextBox : TextBox
    {
        #region Properties
        public int NumberOfDecimals { get; set; }
        #endregion
        
        #region Methods & Event Handlers
        /// <summary>
        /// The core of javascript function calls.
        /// </summary>
        /// <param name="writer"></param>
        protected override void AddAttributesToRender(System.Web.UI.HtmlTextWriter writer)
        {
            if (NumberOfDecimals < 1)
                NumberOfDecimals = 2;
            // Wire up the onkeypress event handler to the ChangeBackgroundColor() JavaScript function
            writer.AddAttribute("onkeydown", "return currencyTextBoxKeyPress(this," + NumberOfDecimals + ");");
            writer.AddAttribute("onfocus", "return unFormatCurrencyTextBox(this)");
            writer.AddAttribute("onblur", "return formatCurrencyTextBox(this)");
            writer.AddStyleAttribute("text-align", "right");
            base.AddAttributesToRender(writer);
        }

        /// <summary>
        /// Register javascript.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnPreRender(EventArgs e)
        {
            // When pre-rendering, add in external JavaScript file
            Page.ClientScript.RegisterClientScriptInclude("CurrencyTextBoxJavaScript", Page.ClientScript.GetWebResourceUrl(this.GetType(), "SKP.ASP.Controls.currencytextbox.js"));
            base.OnPreRender(e);
        }

        /// <summary>
        /// Get the currency amount in decimal.
        /// </summary>
        /// <returns></returns>
        public decimal GetCurrencyAmount()
        {
            string amount = this.Text;
            amount = amount.Replace(",", string.Empty);
            return (decimal.Parse(amount));
        }

        /// <summary>
        /// Return the formatted currency value as string.
        /// </summary>
        /// <returns></returns>
        public string GetFormattedCurrencyAmount()
        {
            return this.Text;
        }
        #endregion
    }
}
