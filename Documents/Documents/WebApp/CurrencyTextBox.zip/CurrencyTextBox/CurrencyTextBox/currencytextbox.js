
/**
Handle currency text box key press.
**/
function currencyTextBoxKeyPress(ctrl, decimalPlaces) {
    var keyCode = event.keyCode;
    var value = ctrl.value;
    if (!allowedNonNumericCodes.contains(keyCode) && !allowedNumericKeyCodes.contains(keyCode))
        return false;
    /**Position of Period, only one period is allowed.**/    
    var dotPos = value.indexOf('.');    
    if (keyCode === 190 && dotPos > 0)
        return false;
    var cursorAt = getCursorLocation(ctrl);
    var allowDecimalPlaces = dotPos + decimalPlaces;
    /**allow only allowDecimalPlaces digits after period**/
    if (dotPos > 0 && !allowedNonNumericCodes.contains(keyCode) && cursorAt > allowDecimalPlaces)
        return false;
    return true;
}

function formatCurrencyTextBox(ctrl) {
    ctrl.value = formatCurrencyValue(ctrl.value);
}

function unFormatCurrencyTextBox(ctrl) {
    ctrl.value = ctrl.value.replace(new RegExp(',', 'g'), '');
}

var allowedNonNumericCodes = new Array(8, 9, 37, 39, 190);
var allowedNumericKeyCodes = new Array(46, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105);

/**
IndexOf function is missing in IE :)
**/
Array.prototype.contains = function(obj) {
    var i = this.length;
    while (i--) {
        if (this[i] === obj) {
            return true;
        }
    }
    return false;
}

/**
Get cursor position in a text box.
**/
function getCursorLocation(CurrentTextBox) {
    var CurrentSelection, FullRange, SelectedRange, LocationIndex = -1;
    if (typeof CurrentTextBox.selectionStart == "number") {
        LocationIndex = CurrentTextBox.selectionStart;
    }
    else if (document.selection && CurrentTextBox.createTextRange) {
        CurrentSelection = document.selection;
        if (CurrentSelection) {
            SelectedRange = CurrentSelection.createRange();
            FullRange = CurrentTextBox.createTextRange();
            FullRange.setEndPoint("EndToStart", SelectedRange);
            LocationIndex = FullRange.text.length;
        }
    }
    return LocationIndex;
}

function formatCurrencyValue(amount) {
    var delimiter = ","; // replace comma if desired
    var a = amount.split('.', 2)
    var d = a[1];
    var i = parseInt(a[0]);
    if (isNaN(i)) { return ''; }
    var minus = '';
    if (i < 0) { minus = '-'; }
    i = Math.abs(i);
    var n = new String(i);
    var a = [];
    while (n.length > 3) {
        var nn = n.substr(n.length - 3);
        a.unshift(nn);
        n = n.substr(0, n.length - 3);
    }
    if (n.length > 0) { a.unshift(n); }
    n = a.join(delimiter);
    if (d == null || d.length < 1) { amount = n; }
    else { amount = n + '.' + d; }
    amount = minus + amount;
    return amount;
}

